import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAuthStore } from "@/features/auth/store/auth.store";
import AuthSidebar from "@/features/auth/components/AuthSidebar";
import LoaderButton from "@/shared/ui/LoaderButton";
import InputField from "@/shared/ui/InputField";
import { errorToast, successToast } from "@/shared/utils/toastUtils";
import { authService } from "@/features/auth/services/authServices";
import { registerSchema } from "@/features/auth/schemas/registerSchema";
import SocialLoginButtons from "@/features/auth/components/SocialLoginButtons";

const Register = () => {
  const setSignupState = useAuthStore((state) => state.setSignupState);
  const navigate = useNavigate();

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });

  const otpMutation = useMutation({
    mutationFn: authService.sendOtp,
  });

  //  Submit Handler
  const onSubmit = (data) => {
    otpMutation.mutate(
      {
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        password: data.password,
        confirmPassword: data.confirmPassword,
      },
      {
        onSuccess: (res) => {
          setSignupState({ email: data.email });
          successToast(res?.message || "OTP sent successfully");
          navigate("/verify-otp");
        },
        onError: (error) => {
          const message =
            error?.response?.data?.message || "Failed to send OTP";
          const backendErrors = error?.response?.data?.errors;

          if (backendErrors) {
            Object.keys(backendErrors).forEach((field) => {
              setError(field, {
                type: "server",
                message: backendErrors[field],
              });
            });
          } else {
            errorToast(message);
          }
        },
      }
    );
  };

  return (
    <AuthSidebar
      image="https://res.cloudinary.com/du7xquzsm/image/upload/v1763812843/Register_image_mriulk.jpg"
      title="Let the Journey Begin!"
      subtitle="Unlock your learning potential — create an account to start your LMS journey."
    >
      {/* Header */}
      <div className="text-center mb-6 sm:mb-8">
        <h2 className="font-display text-3xl sm:text-4xl font-bold mb-1 text-gold">
          Create Account
        </h2>
        <p className="text-text-2 text-sm sm:text-base">
          Start your learning journey today
        </p>
      </div>

      <SocialLoginButtons />

      <div className="flex items-center gap-4 my-6 sm:my-8">
        <div className="flex-1 h-px bg-gradient-to-r from-transparent via-border-strong to-transparent"></div>
        <span className="text-text-3 text-xs sm:text-sm">OR</span>
        <div className="flex-1 h-px bg-gradient-to-r from-transparent via-border-strong to-transparent"></div>
      </div>

      {/* FORM */}
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="space-y-5 sm:space-y-6"
      >
        {/* First/Last */}
        <div className="grid sm:grid-cols-2 gap-4 sm:gap-5">
          <InputField
            label="First Name"
            placeholder="John"
            error={errors.firstName?.message}
            {...register("firstName")}
          />

          <InputField
            label="Last Name"
            placeholder="Doe"
            error={errors.lastName?.message}
            {...register("lastName")}
          />
        </div>

        {/* Email */}
        <InputField
          label="Email Address"
          type="email"
          placeholder="you@example.com"
          error={errors.email?.message}
          {...register("email")}
        />

        {/* Passwords */}
        <div className="grid sm:grid-cols-2 gap-4 sm:gap-5">
          <InputField
            label="Password"
            type="password"
            placeholder="••••••••"
            error={errors.password?.message}
            showPasswordToggle
            isPasswordVisible={showPassword}
            onPasswordToggle={() => setShowPassword(!showPassword)}
            {...register("password")}
            helpText="Min 8 chars, uppercase & number"
          />

          <InputField
            label="Confirm Password"
            type="password"
            placeholder="••••••••"
            error={errors.confirmPassword?.message}
            showPasswordToggle
            isPasswordVisible={showConfirmPassword}
            onPasswordToggle={() =>
              setShowConfirmPassword(!showConfirmPassword)
            }
            {...register("confirmPassword")}
          />
        </div>

        <LoaderButton
          text="Create Account"
          loadingText="Sending OTP..."
          loading={otpMutation.isPending}
          type="submit"
        />

        <p className="text-center mt-6 sm:mt-8 text-text-2 text-xs sm:text-sm">
          Already have an account?{" "}
          <Link
            to="/login"
            className="text-gold hover:text-gold/80 font-semibold transition-colors"
          >
            Sign In
          </Link>
        </p>
      </form>
    </AuthSidebar>
  );
};

export default Register;
