import { useState } from "react";
import {
  X,
  Upload,
  FileText,
  Calendar,
  Award,
  CheckCircle,
  Clock,
} from "lucide-react";

const Assignments = () => {
  const [activeFilter, setActiveFilter] = useState("all");
  const [assignments] = useState([]);
  const [loading] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState(null);
  const [showSubmitModal, setShowSubmitModal] = useState(null);
  const [submissionFile, setSubmissionFile] = useState(null);
  const [submissionNotes, setSubmissionNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Fetch assignments from backend

  // Mock data for development

  const filteredAssignments = assignments.filter((assignment) => {
    if (activeFilter === "all") return true;
    return assignment.status === activeFilter;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case "pending":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30";
      case "submitted":
        return "bg-gold/20 text-gold border-gold/30";
      case "graded":
        return "bg-green-500/20 text-green-400 border-green-500/30";
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30";
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "pending":
        return <Clock className="w-4 h-4" />;
      case "submitted":
        return <Upload className="w-4 h-4" />;
      case "graded":
        return <CheckCircle className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const formatDueDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = date - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 0) return "Due Today";
    if (diffDays === 1) return "Due Tomorrow";
    if (diffDays > 1) return `Due in ${diffDays} days`;
    return "Overdue";
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSubmissionFile(file);
    }
  };

  const handleSubmitAssignment = async () => {
    if (!submissionFile) {
      alert("Please upload a file");
      return;
    }

    setSubmitting(true);

    try {
      const formData = new FormData();
      formData.append("file", submissionFile);
      formData.append("notes", submissionNotes);
      formData.append("assignmentId", showSubmitModal.id);

      // Replace with your actual API endpoint
      const response = await fetch(
        `/api/assignments/${showSubmitModal.id}/submit`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
          body: formData,
        }
      );

      if (response.ok) {
        // Refresh assignments
        await fetchAssignments();

        // Close modal and reset
        setShowSubmitModal(null);
        setSubmissionFile(null);
        setSubmissionNotes("");

        alert("Assignment submitted successfully!");
      } else {
        throw new Error("Submission failed");
      }
    } catch (error) {
      console.error("Submission error:", error);
      alert("Failed to submit assignment. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gold mx-auto mb-4"></div>
          <p className="text-text-2">Loading assignments...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface text-slate-100 p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">My Assignments</h1>
        <p className="text-text-2">
          Manage and submit your course assignments
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-gradient-to-br from-surface-2 to-surface-2/50 rounded-xl p-5 border border-border">
          <div className="text-3xl font-bold text-white mb-1">
            {assignments.length}
          </div>
          <div className="text-text-2 text-sm">Total Assignments</div>
        </div>
        <div className="bg-gradient-to-br from-yellow-500/10 to-yellow-500/5 rounded-xl p-5 border border-yellow-500/20">
          <div className="text-3xl font-bold text-yellow-400 mb-1">
            {assignments.filter((a) => a.status === "pending").length}
          </div>
          <div className="text-text-2 text-sm">Pending</div>
        </div>
        <div className="bg-gradient-to-br from-blue-500/10 to-blue-500/5 rounded-xl p-5 border border-gold/20">
          <div className="text-3xl font-bold text-gold mb-1">
            {assignments.filter((a) => a.status === "submitted").length}
          </div>
          <div className="text-text-2 text-sm">Submitted</div>
        </div>
        <div className="bg-gradient-to-br from-green-500/10 to-green-500/5 rounded-xl p-5 border border-green-500/20">
          <div className="text-3xl font-bold text-green-400 mb-1">
            {assignments.filter((a) => a.status === "graded").length}
          </div>
          <div className="text-text-2 text-sm">Graded</div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-surface-2 rounded-xl p-4 mb-6 border border-border">
        <div className="flex flex-wrap gap-2">
          {["all", "pending", "submitted", "graded"].map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition-all ${
                activeFilter === filter
                  ? "bg-gold text-white shadow-lg shadow-gold-glow/20"
                  : "text-text-2 hover:text-white hover:bg-surface-2"
              }`}
            >
              {filter === "all" ? "All Assignments" : filter}
            </button>
          ))}
        </div>
      </div>

      {/* Assignments List */}
      <div className="space-y-4">
        {filteredAssignments.map((assignment) => (
          <div
            key={assignment.id}
            className="bg-surface-2 rounded-xl p-6 border border-border hover:border-border-strong transition-all hover:shadow-lg hover:shadow-black/20"
          >
            <div className="flex justify-between items-start mb-4">
              <div className="flex-1">
                <div className="flex items-start gap-3 mb-3">
                  <h3 className="font-bold text-white text-xl">
                    {assignment.title}
                  </h3>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium border flex items-center gap-1.5 ${getStatusColor(
                      assignment.status
                    )}`}
                  >
                    {getStatusIcon(assignment.status)}
                    {assignment.status.charAt(0).toUpperCase() +
                      assignment.status.slice(1)}
                  </span>
                </div>
                <p className="text-gold text-sm mb-1 font-medium">
                  {assignment.course}
                </p>
                <p className="text-text-2 text-sm mb-3">
                  {assignment.description}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap justify-between items-center gap-4">
              <div className="flex items-center gap-6 text-sm">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-text-2" />
                  <div>
                    <span
                      className={`font-medium ${
                        assignment.status === "pending" &&
                        formatDueDate(assignment.dueDate) === "Overdue"
                          ? "text-red-400"
                          : "text-text-2"
                      }`}
                    >
                      {formatDueDate(assignment.dueDate)}
                    </span>
                    <div className="text-xs text-text-3">
                      {new Date(assignment.dueDate).toLocaleDateString(
                        "en-US",
                        {
                          month: "short",
                          day: "numeric",
                          year: "numeric",
                        }
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Award className="w-4 h-4 text-text-2" />
                  <div>
                    <span className="font-medium text-text-2">
                      {assignment.points}
                    </span>
                    <div className="text-xs text-text-3">Points</div>
                  </div>
                </div>

                {assignment.grade && (
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <div>
                      <span className="font-medium text-green-400 text-lg">
                        {assignment.grade}
                      </span>
                      {assignment.score && (
                        <div className="text-xs text-text-3">
                          {assignment.score}/{assignment.points}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                {assignment.status === "pending" && (
                  <button
                    onClick={() => setShowSubmitModal(assignment)}
                    className="bg-gold hover:bg-gold-dim text-white px-5 py-2.5 rounded-lg text-sm font-medium transition-all shadow-lg shadow-gold-glow/20 hover:shadow-gold-glow/30"
                  >
                    Submit Assignment
                  </button>
                )}
                <button
                  onClick={() => setSelectedAssignment(assignment)}
                  className="border border-border-strong hover:border-border-strong hover:bg-surface-2 text-text-2 px-5 py-2.5 rounded-lg text-sm font-medium transition-all"
                >
                  View Details
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredAssignments.length === 0 && (
        <div className="text-center py-16 bg-surface-2 rounded-xl border border-border">
          <div className="text-6xl mb-4">📝</div>
          <h3 className="text-xl font-medium text-white mb-2">
            No assignments found
          </h3>
          <p className="text-text-2">
            You don't have any {activeFilter !== "all" ? activeFilter : ""}{" "}
            assignments
          </p>
        </div>
      )}

      {/* Details Modal */}
      {selectedAssignment && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-surface-2 rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto border border-border">
            {/* Modal Header */}
            <div className="sticky top-0 bg-surface-2 border-b border-border p-6 flex justify-between items-start">
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-white mb-2">
                  {selectedAssignment.title}
                </h2>
                <p className="text-gold text-sm">
                  {selectedAssignment.course}
                </p>
                {selectedAssignment.instructor && (
                  <p className="text-text-2 text-sm mt-1">
                    Instructor: {selectedAssignment.instructor}
                  </p>
                )}
              </div>
              <button
                onClick={() => setSelectedAssignment(null)}
                className="text-text-2 hover:text-white p-2 hover:bg-surface-2 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-6">
              {/* Status and Info */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-surface rounded-lg p-4">
                  <div className="text-text-2 text-sm mb-1">Status</div>
                  <span
                    className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(selectedAssignment.status)}`}
                  >
                    {getStatusIcon(selectedAssignment.status)}
                    {selectedAssignment.status.charAt(0).toUpperCase() +
                      selectedAssignment.status.slice(1)}
                  </span>
                </div>
                <div className="bg-surface rounded-lg p-4">
                  <div className="text-text-2 text-sm mb-1">Due Date</div>
                  <div className="text-white font-medium">
                    {new Date(selectedAssignment.dueDate).toLocaleDateString(
                      "en-US",
                      {
                        weekday: "long",
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      }
                    )}
                  </div>
                  <div className="text-text-2 text-sm mt-1">
                    {formatDueDate(selectedAssignment.dueDate)}
                  </div>
                </div>
                <div className="bg-surface rounded-lg p-4">
                  <div className="text-text-2 text-sm mb-1">Points</div>
                  <div className="text-white font-medium text-xl">
                    {selectedAssignment.points}
                  </div>
                </div>
                {selectedAssignment.grade && (
                  <div className="bg-surface rounded-lg p-4">
                    <div className="text-text-2 text-sm mb-1">Grade</div>
                    <div className="text-green-400 font-bold text-2xl">
                      {selectedAssignment.grade}
                    </div>
                    {selectedAssignment.score && (
                      <div className="text-text-2 text-sm">
                        {selectedAssignment.score}/{selectedAssignment.points}{" "}
                        points
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Description */}
              <div>
                <h3 className="text-white font-semibold mb-2">Description</h3>
                <p className="text-text-2">
                  {selectedAssignment.description}
                </p>
              </div>

              {/* Requirements */}
              {selectedAssignment.requirements && (
                <div>
                  <h3 className="text-white font-semibold mb-3">
                    Requirements
                  </h3>
                  <ul className="space-y-2">
                    {selectedAssignment.requirements.map((req, index) => (
                      <li
                        key={index}
                        className="flex items-start gap-2 text-text-2"
                      >
                        <CheckCircle className="w-5 h-5 text-gold mt-0.5 flex-shrink-0" />
                        <span>{req}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Attachments */}
              {selectedAssignment.attachments &&
                selectedAssignment.attachments.length > 0 && (
                  <div>
                    <h3 className="text-white font-semibold mb-3">
                      Course Materials
                    </h3>
                    <div className="space-y-2">
                      {selectedAssignment.attachments.map((file, index) => (
                        <a
                          key={index}
                          href={file.url}
                          className="flex items-center gap-3 bg-surface p-3 rounded-lg hover:bg-surface-2 transition-colors"
                        >
                          <FileText className="w-5 h-5 text-gold" />
                          <span className="text-text-2">{file.name}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}

              {/* Submission Info */}
              {selectedAssignment.submitted &&
                selectedAssignment.submissionFiles && (
                  <div>
                    <h3 className="text-white font-semibold mb-3">
                      Your Submission
                    </h3>
                    <div className="bg-surface rounded-lg p-4 space-y-3">
                      <div className="text-sm text-text-2">
                        Submitted on:{" "}
                        {new Date(
                          selectedAssignment.submittedAt
                        ).toLocaleString("en-US", {
                          dateStyle: "long",
                          timeStyle: "short",
                        })}
                      </div>
                      <div className="space-y-2">
                        {selectedAssignment.submissionFiles.map(
                          (file, index) => (
                            <div
                              key={index}
                              className="flex items-center justify-between bg-surface-2 p-3 rounded-lg"
                            >
                              <div className="flex items-center gap-3">
                                <FileText className="w-5 h-5 text-green-400" />
                                <span className="text-text-2">
                                  {file.name}
                                </span>
                              </div>
                              <span className="text-text-2 text-sm">
                                {file.size}
                              </span>
                            </div>
                          )
                        )}
                      </div>
                    </div>
                  </div>
                )}

              {/* Feedback */}
              {selectedAssignment.feedback && (
                <div>
                  <h3 className="text-white font-semibold mb-3">
                    Instructor Feedback
                  </h3>
                  <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
                    <p className="text-text-2">
                      {selectedAssignment.feedback}
                    </p>
                  </div>
                </div>
              )}

              {/* Action Button */}
              {selectedAssignment.status === "pending" && (
                <button
                  onClick={() => {
                    setSelectedAssignment(null);
                    setShowSubmitModal(selectedAssignment);
                  }}
                  className="w-full bg-gold hover:bg-gold-dim text-white px-6 py-3 rounded-lg font-medium transition-all shadow-lg shadow-gold-glow/20"
                >
                  Submit Assignment
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Submit Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-surface-2 rounded-2xl max-w-2xl w-full border border-border">
            <div className="border-b border-border p-6 flex justify-between items-center">
              <h2 className="text-2xl font-bold text-white">
                Submit Assignment
              </h2>
              <button
                onClick={() => {
                  setShowSubmitModal(null);
                  setSubmissionFile(null);
                  setSubmissionNotes("");
                }}
                className="text-text-2 hover:text-white p-2 hover:bg-surface-2 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div>
                <h3 className="text-white font-semibold mb-2">
                  {showSubmitModal.title}
                </h3>
                <p className="text-text-2 text-sm">
                  {showSubmitModal.course}
                </p>
              </div>

              {/* File Upload */}
              <div>
                <label className="block text-white font-medium mb-2">
                  Upload File *
                </label>
                <div className="border-2 border-dashed border-border-strong rounded-lg p-8 text-center hover:border-gold transition-colors">
                  <input
                    type="file"
                    onChange={handleFileChange}
                    className="hidden"
                    id="file-upload"
                  />
                  <label
                    htmlFor="file-upload"
                    className="cursor-pointer flex flex-col items-center"
                  >
                    <Upload className="w-12 h-12 text-text-2 mb-3" />
                    {submissionFile ? (
                      <div className="text-white font-medium">
                        {submissionFile.name}
                      </div>
                    ) : (
                      <>
                        <div className="text-white font-medium mb-1">
                          Click to upload or drag and drop
                        </div>
                        <div className="text-text-2 text-sm">
                          PDF, DOC, DOCX, ZIP (Max 10MB)
                        </div>
                      </>
                    )}
                  </label>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-white font-medium mb-2">
                  Submission Notes (Optional)
                </label>
                <textarea
                  value={submissionNotes}
                  onChange={(e) => setSubmissionNotes(e.target.value)}
                  placeholder="Add any notes or comments for your instructor..."
                  className="w-full bg-surface border border-border-strong rounded-lg p-3 text-white placeholder-text-3 focus:outline-none focus:ring-2 focus:ring-gold"
                  rows="4"
                />
              </div>

              {/* Submit Button */}
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowSubmitModal(null);
                    setSubmissionFile(null);
                    setSubmissionNotes("");
                  }}
                  className="flex-1 border border-border-strong hover:bg-surface-2 text-text-2 px-6 py-3 rounded-lg font-medium transition-colors"
                  disabled={submitting}
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmitAssignment}
                  disabled={!submissionFile || submitting}
                  className="flex-1 bg-gold hover:bg-gold-dim disabled:bg-surface-2 disabled:text-text-3 text-white px-6 py-3 rounded-lg font-medium transition-all shadow-lg shadow-gold-glow/20"
                >
                  {submitting ? "Submitting..." : "Submit Assignment"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Assignments;
